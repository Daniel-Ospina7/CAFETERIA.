// Función para desplazarse a una sección específica
function scrollToSection(sectionId) {
    const section = document.getElementById(sectionId);
    if (section) {
        window.scrollTo({
            top: section.offsetTop - 80, // Ajuste para el header fijo
            behavior: 'smooth'
        });
    }
}

// Manejo del formulario de reservación
document.addEventListener('DOMContentLoaded', function() {
    const reservationForm = document.getElementById('reservationForm');
    const confirmationModal = document.getElementById('confirmationModal');
    const reservationDetails = document.getElementById('reservationDetails');
    
    if (reservationForm) {
        reservationForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Recopilar datos del formulario
            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const phone = document.getElementById('phone').value;
            const date = document.getElementById('date').value;
            const time = document.getElementById('time').value;
            const guests = document.getElementById('guests').value;
            
            // Formatear fecha
            const formattedDate = new Date(date).toLocaleDateString('es-ES', {
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric'
            });
            
            // Mostrar detalles de la reservación
            reservationDetails.innerHTML = `
                <p><strong>Nombre:</strong> ${name}</p>
                <p><strong>Fecha:</strong> ${formattedDate}</p>
                <p><strong>Hora:</strong> ${time}</p>
                <p><strong>Personas:</strong> ${guests}</p>
                <p><strong>Contacto:</strong> ${email} / ${phone}</p>
            `;
            
            // Mostrar modal de confirmación
            confirmationModal.style.display = 'flex';
            
            // Limpiar formulario
            reservationForm.reset();
        });
    }
    
    // Carrito de compras
let cart = [];
let isCartOpen = false;

// Función para agregar productos al carrito
function addToCart(name, price, image) {
    // Verificar si el producto ya está en el carrito
    const existingItemIndex = cart.findIndex(item => item.name === name);
    
    if (existingItemIndex !== -1) {
        // Si el producto ya existe, incrementar la cantidad
        cart[existingItemIndex].quantity++;
    } else {
        // Si es un producto nuevo, añadirlo al carrito
        cart.push({
            name: name,
            price: price,
            image: image,
            quantity: 1
        });
    }
    
    // Actualizar la interfaz
    updateCartUI();
    
    // Mostrar mensaje de confirmación
    showToast(`${name} agregado al carrito`);
    
    // Si el carrito está cerrado, mostrar una animación en el botón
    if (!isCartOpen) {
        const cartButton = document.getElementById('cart-button');
        cartButton.classList.add('pulse');
        setTimeout(() => {
            cartButton.classList.remove('pulse');
        }, 500);
    }
}

// Función para actualizar la interfaz del carrito
function updateCartUI() {
    const cartCount = document.getElementById('cart-count');
    const cartItems = document.getElementById('cart-items');
    const cartTotalPrice = document.getElementById('cart-total-price');
    
    // Actualizar el contador del carrito
    const totalItems = cart.reduce((total, item) => total + item.quantity, 0);
    cartCount.textContent = totalItems;
    
    // Limpiar el contenido actual del carrito
    cartItems.innerHTML = '';
    
    // Si el carrito está vacío
    if (cart.length === 0) {
        cartItems.innerHTML = '<p class="empty-cart">Tu carrito está vacío</p>';
        cartTotalPrice.textContent = '$0.00';
        return;
    }
    
    // Calcular el total
    let total = 0;
    
    // Agregar cada producto al panel del carrito
    cart.forEach((item, index) => {
        const itemTotal = item.price * item.quantity;
        total += itemTotal;
        
        const cartItem = document.createElement('div');
        cartItem.className = 'cart-item';
        cartItem.innerHTML = `
            <div class="cart-item-image">
                <img src="${item.image}" alt="${item.name}">
            </div>
            <div class="cart-item-details">
                <h4>${item.name}</h4>
                <p>$${item.price.toFixed(2)} x ${item.quantity}</p>
            </div>
            <div class="cart-item-actions">
                <button onclick="decreaseQuantity(${index})">-</button>
                <span>${item.quantity}</span>
                <button onclick="increaseQuantity(${index})">+</button>
                <button onclick="removeFromCart(${index})" class="remove-btn">×</button>
            </div>
        `;
        
        cartItems.appendChild(cartItem);
    });
    
    // Actualizar el precio total
    cartTotalPrice.textContent = `$${total.toFixed(2)}`;
}

// Función para aumentar la cantidad de un producto
function increaseQuantity(index) {
    cart[index].quantity++;
    updateCartUI();
}

// Función para disminuir la cantidad de un producto
function decreaseQuantity(index) {
    if (cart[index].quantity > 1) {
        cart[index].quantity--;
    } else {
        removeFromCart(index);
    }
    updateCartUI();
}

// Función para eliminar un producto del carrito
function removeFromCart(index) {
    const removedItem = cart[index];
    cart.splice(index, 1);
    updateCartUI();
    showToast(`${removedItem.name} eliminado del carrito`);
}

// Función para mostrar/ocultar el panel del carrito
function toggleCart() {
    const cartPanel = document.getElementById('cart-panel');
    isCartOpen = !isCartOpen;
    
    if (isCartOpen) {
        cartPanel.classList.add('open');
    } else {
        cartPanel.classList.remove('open');
    }
}

// Función para mostrar mensajes temporales (toast)
function showToast(message) {
    // Verificar si ya existe un toast y eliminarlo
    const existingToast = document.querySelector('.toast');
    if (existingToast) {
        existingToast.remove();
    }
    
    // Crear nuevo toast
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    
    // Añadir el toast al body
    document.body.appendChild(toast);
    
    // Mostrar el toast
    setTimeout(() => {
        toast.classList.add('show');
    }, 10);
    
    // Ocultar y eliminar después de 3 segundos
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            toast.remove();
        }, 300);
    }, 3000);
}

// Inicializar el carrito al cargar la página
document.addEventListener('DOMContentLoaded', function() {
    updateCartUI();
    
    // Manejar el proceso de checkout
    const checkoutButton = document.getElementById('checkout-button');
    if (checkoutButton) {
        checkoutButton.addEventListener('click', function() {
            if (cart.length === 0) {
                showToast('Tu carrito está vacío');
                return;
            }
            
            // Aquí se implementaría la lógica para procesar el pedido
            // Por ahora, solo mostramos un mensaje y vaciamos el carrito
            showToast('¡Pedido realizado con éxito!');
            cart = [];
            updateCartUI();
            toggleCart();
        });
    }
    
    // Función para desplazarse a una sección específica
    window.scrollToSection = function(sectionId) {
        const section = document.getElementById(sectionId);
        if (section) {
            window.scrollTo({
                top: section.offsetTop - 80, // Ajuste para el header fijo
                behavior: 'smooth'
            });
        }
    };
    
    // Manejo del formulario de reservación
    const reservationForm = document.getElementById('reservationForm');
    const confirmationModal = document.getElementById('confirmationModal');
    const reservationDetails = document.getElementById('reservationDetails');
    
    if (reservationForm) {
        reservationForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Recopilar datos del formulario
            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const phone = document.getElementById('phone').value;
            const date = document.getElementById('date').value;
            const time = document.getElementById('time').value;
            const guests = document.getElementById('guests').value;
            
            // Formatear fecha
            const formattedDate = new Date(date).toLocaleDateString('es-ES', {
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric'
            });
            
            // Mostrar detalles de la reservación
            reservationDetails.innerHTML = `
                <p><strong>Nombre:</strong> ${name}</p>
                <p><strong>Fecha:</strong> ${formattedDate}</p>
                <p><strong>Hora:</strong> ${time}</p>
                <p><strong>Personas:</strong> ${guests}</p>
                <p><strong>Contacto:</strong> ${email} / ${phone}</p>
            `;
            
            // Mostrar modal de confirmación
            confirmationModal.style.display = 'flex';
            
            // Limpiar formulario
            reservationForm.reset();
        });
    }
    
    // Carrusel de imágenes
    const slides = document.querySelectorAll('.carousel-slide');
    const indicators = document.querySelectorAll('.carousel-indicator');
    const prevBtn = document.querySelector('.carousel-btn-prev');
    const nextBtn = document.querySelector('.carousel-btn-next');
    let currentSlide = 0;
    let interval;
        
    // Función para mostrar un slide específico
    function showSlide(index) {
        // Ocultar todos los slides
        slides.forEach(slide => {
            slide.classList.remove('active');
        });
        
        // Desactivar todos los indicadores
        indicators.forEach(indicator => {
            indicator.classList.remove('active');
        });
        
        // Mostrar el slide actual
        if (slides[index]) {
            slides[index].classList.add('active');
            indicators[index].classList.add('active');
            currentSlide = index;
        }
    }
    
    // Función para el slide siguiente
    function nextSlide() {
        let next = currentSlide + 1;
        if (next >= slides.length) {
            next = 0;
        }
        showSlide(next);
    }
    
    // Función para el slide anterior
    function prevSlide() {
        let prev = currentSlide - 1;
        if (prev < 0) {
            prev = slides.length - 1;
        }
        showSlide(prev);
    }
    
    // Configurar eventos para los botones de navegación del carrusel
    if (prevBtn && nextBtn) {
        prevBtn.addEventListener('click', function() {
            prevSlide();
            resetInterval();
        });
        
        nextBtn.addEventListener('click', function() {
            nextSlide();
            resetInterval();
        });
    }
    
    // Configurar evento para los indicadores
    indicators.forEach((indicator, index) => {
        indicator.addEventListener('click', function() {
            showSlide(index);
            resetInterval();
        });
    });
    
    // Función para reiniciar el intervalo automático
    function resetInterval() {
        clearInterval(interval);
        startInterval();
    }
    
    // Función para iniciar el intervalo automático
    function startInterval() {
        interval = setInterval(nextSlide, 5000); // Cambiar cada 5 segundos
    }
    
    // Iniciar el carrusel si hay slides
    if (slides.length > 0) {
        startInterval();
    }
});

// Cerrar modal
function closeModal() {
    const confirmationModal = document.getElementById('confirmationModal');
    if (confirmationModal) {
        confirmationModal.style.display = 'none';
    }
}

// Cerrar modal si se hace clic fuera del contenido
window.addEventListener('click', function(e) {
    const confirmationModal = document.getElementById('confirmationModal');
    if (e.target === confirmationModal) {
        closeModal();
    }
});

    // Carrusel de imágenes
    const slides = document.querySelectorAll('.carousel-slide');
    const indicators = document.querySelectorAll('.carousel-indicator');
    const prevBtn = document.querySelector('.carousel-btn-prev');
    const nextBtn = document.querySelector('.carousel-btn-next');
    let currentSlide = 0;
    let interval;
        
    // Función para mostrar un slide específico
    function showSlide(index) {
        // Ocultar todos los slides
        slides.forEach(slide => {
            slide.classList.remove('active');
        });
        
        // Desactivar todos los indicadores
        indicators.forEach(indicator => {
            indicator.classList.remove('active');
        });
        
        // Mostrar el slide actual
        slides[index].classList.add('active');
        indicators[index].classList.add('active');
        currentSlide = index;
    }
    
    // Función para el slide siguiente
    function nextSlide() {
        let next = currentSlide + 1;
        if (next >= slides.length) {
            next = 0;
        }
        showSlide(next);
    }
    
    // Función para el slide anterior
    function prevSlide() {
        let prev = currentSlide - 1;
        if (prev < 0) {
            prev = slides.length - 1;
        }
        showSlide(prev);
    }
    
    // Configurar eventos para los botones de navegación del carrusel
    if (prevBtn && nextBtn) {
        prevBtn.addEventListener('click', function() {
            prevSlide();
            resetInterval();
        });
        
        nextBtn.addEventListener('click', function() {
            nextSlide();
            resetInterval();
        });
    }
    
    // Configurar evento para los indicadores
    indicators.forEach((indicator, index) => {
        indicator.addEventListener('click', function() {
            showSlide(index);
            resetInterval();
        });
    });
    
    // Función para reiniciar el intervalo automático
    function resetInterval() {
        clearInterval(interval);
        startInterval();
    }
    
    // Función para iniciar el intervalo automático
    function startInterval() {
        interval = setInterval(nextSlide, 5000); // Cambiar cada 5 segundos
    }
    
    // Iniciar el carrusel si hay slides
    if (slides.length > 0) {
        startInterval();
    }
});

// Cerrar modal
function closeModal() {
    const confirmationModal = document.getElementById('confirmationModal');
    if (confirmationModal) {
        confirmationModal.style.display = 'none';
    }
}

// Cerrar modal si se hace clic fuera del contenido
window.addEventListener('click', function(e) {
    const confirmationModal = document.getElementById('confirmationModal');
    if (e.target === confirmationModal) {
        closeModal();
    }
});